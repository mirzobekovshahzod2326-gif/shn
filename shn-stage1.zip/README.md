# Sh+N — 1-bosqich (v0.1.0)

## GitHub’ga joylash (telefondan)
1. GitHub’da yangi repo oching (masalan `shn`).
2. “Add file → Upload files” → zip’ni **avval Samsung “Mening fayllarim”da oching**, ichidagi hamma fayllarni tanlang (papka yo‘q, hammasi bitta qatlamda). “Commit changes”.
3. Settings → Pages → Branch: `main`, papka: `/ (root)` → Save.
4. 1–2 daqiqadan keyin: `https://FOYDALANUVCHI.github.io/shn/` — shu manzilni Chrome’da oching.
5. Chrome menyusi → “Ilovani o‘rnatish”.

## Har yangilanishda
`sw.js` ichidagi `VERSION` ni o‘zgartiring (masalan `0.1.1`). Aks holda telefonlar yangi versiyani ko‘rmaydi.

## Fayllar (12 ta ilova fayli)
index.html · styles.css · app.js · i18n.js · db.js · boot.js · sw.js · manifest.webmanifest · icon-192.png · icon-512.png · icon-maskable-512.png · apple-touch-icon.png
