# Sh+N — arxitektura va xavfsizlik rejasi (v1)

Holat: **1-bosqich tayyor** (ilova qobig‘i). Qolgan hamma narsa — reja, hali kodlanmagan.

## Asosiy qarorlar
- Offline-first: hamma ma’lumot avval IndexedDB’ga yoziladi. Cloud ixtiyoriy.
- Frameworksiz sof JS, fayllar bitta papkada (telefondan GitHub’ga yuklash oson).
- CSP (`script-src 'self'`): begona skript ishlamaydi. Supabase ulanganda `connect-src` ga faqat o‘sha manzil qo‘shiladi.

## Talablar bo‘yicha dizayn

**1. Sinxronda yozuv yo‘qolmasligi.** Har yozuvda o‘zgarmas `id` (UUID), `rev`, `updatedAt`, `deviceId`. O‘chirish = `deletedAt` belgisi (qattiq o‘chirish yo‘q). Serverda eski versiyalar `vault_revisions` jadvalida saqlanadi. Yozuv faqat tasdiqlangandan keyin navbatdan olib tashlanadi.

**2. PIN va shifrlash paroli alohida.**
- Asosiy parol → PBKDF2-SHA256 (≥600 000 iteratsiya) → kalit, u tasodifiy 256-bitli **ma’lumot kalitini** (DEK) o‘raydi. Ma’lumot DEK bilan AES-GCM’da shifrlanadi.
- PIN faqat shu qurilmada tez ochish uchun: PIN → alohida kalit → DEK’ning qurilmadagi nusxasi. 5 ta xato urinishdan keyin parol so‘raladi. Cloudga PIN hech qachon chiqmaydi.
- *Cheklov:* 4–6 xonali PIN, agar kimdir qurilma xotirasini nusxalab olsa, oflayn topib olinishi mumkin. Shuning uchun PIN faqat qulay kirish uchun, haqiqiy himoya — parol.

**3. 24 so‘zli Recovery Key.** 256 bit tasodifiy → 24 so‘z. DEK ikkinchi marta shu kalit bilan o‘raladi. Yaratilganda foydalanuvchi tasodifiy 3 so‘zni qayta yozib tasdiqlaydi. Tiklash: 24 so‘z → DEK ochiladi → yangi parol o‘rnatiladi. *Parol ham, kalit ham yo‘qolsa — ma’lumot tiklanmaydi.* So‘zlar ro‘yxati (2048 so‘z) 2-bosqichda tekshirilgan manbadan olinadi.

**4. Konfliktlar.** Bir yozuv ikki qurilmada o‘zgarsa: yangisi asosiy bo‘ladi, ikkinchisi “konflikt nusxa” sifatida saqlanadi va foydalanuvchiga ko‘rsatiladi. Hech narsa jimgina tashlanmaydi.

**5. Sinxron navbati.** `syncQueue` (IndexedDB) tarmoqdan oldin yoziladi. Har amalning `opId` si bor (takror yuborilsa zarar yo‘q). Internet qaytganda, ilova ochilganda qayta uriniladi (kuchayib boruvchi kutish bilan). *iPhone’da fonda sinxron yo‘q* — ilova ochiq bo‘lganda ishlaydi.

**6. Yangilanishda ma’lumot saqlanishi.** (1-bosqichda qurilgan va sinalgan.) Migratsiyalar raqamlangan, faqat qo‘shiladi; eski do‘kon va ma’lumot o‘chirilmaydi. Service Worker faqat keshni almashtiradi, IndexedDB’ga tegmaydi. Yangi versiya foydalanuvchi “Yangilash” bosganda yoqiladi.

**7. Shifrlangan JSON zaxira.** Fayl: `{format, v, salt, iterations, iv, ciphertext}`, AES-GCM. Import: avval imzo/versiya/tuzilish tekshiriladi, nechta yozuv borligi ko‘rsatiladi, foydalanuvchi tasdiqlagach qo‘shiladi (mavjudni ustiga yozmaydi). Sinov: aylanma (eksport→import), buzilgan fayl, noto‘g‘ri parol.

**8. Hamma ma’lumotni o‘chirish.** Sozlamalarda tasdiq so‘zini yozish talab qilinadi. Qurilmada: IndexedDB, kesh, localStorage, service worker. Cloudda (7-bosqich): serverdagi yozuvlar, fayllar va hisobni o‘chiradigan Supabase Edge Function (hisobni o‘chirish xizmat kaliti talab qiladi, brauzerdan qilib bo‘lmaydi).

## Ma’lumotlar sxemasi (IndexedDB)
`settings` (1-bosqichda bor) · `entries` · `moods` · `goals` · `gratitude` · `media` · `categories` · `syncQueue` · `keys` (o‘ralgan kalitlar). Har biri alohida migratsiya bilan qo‘shiladi.

## Bosqichlar
1. ✅ Qobiq, dizayn, til, mavzu, oflayn, yangilanish, migratsiya asosi
2. Shifrlash, parol, PIN, Recovery Key, qulf
3. Yozuvlar: muharrir, avtosaqlash, qidiruv, kategoriya, sevimli, savatcha
4. Kalendar, kayfiyat, maqsadlar, minnatdorchilik, statistika
5. Rasm va audio
6. TXT/PDF eksport, shifrlangan zaxira/tiklash, hamma ma’lumotni o‘chirish
7. Supabase: login, shifrlangan sinxron, konfliktlar, navbat
8. Google Play paketi (GitHub Actions orqali)
