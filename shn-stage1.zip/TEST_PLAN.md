# Sh+N — test rejasi

Avtomatik testlar (Chromium, kompyuter muhitida) 1-bosqich uchun o‘tkazilgan. Quyidagi qo‘lda testlar **haqiqiy telefonlarda** o‘tkazilishi shart — ularni men bajara olmayman.

## A. Android Chrome (Samsung Galaxy)
1. Sayt ochiladi, “Qurilma xotirasi: Ishlayapti”.
2. Menyu → “Ilovani o‘rnatish”. Bosh ekranda ikonka paydo bo‘ladi, ilova to‘liq ekranda ochiladi.
3. Samolyot rejimi → ilovani yop va qayta och → ishlaydi.
4. Til: O‘zbek → Rus → Tojik. Ilovani yopib ochgandan keyin tanlov saqlanadi.
5. Mavzu: Tizim / Yorug‘ / Tungi. Telefon mavzusini o‘zgartirib “Tizim” tekshiriladi.
6. Telefonni gorizontal burib ko‘r, ekran buzilmasin.
7. Yangilanish: GitHub’da `sw.js` dagi VERSION’ni o‘zgartir → Sozlamalar → “Yangilanishni tekshirish” → “Yangilash”.
8. Chrome “Site settings → Clear data” bosilsa ma’lumot o‘chadi (kutilgan holat).

## B. iPhone Safari (iOS 16.4+)
1. Sayt ochiladi, xotira holati “Ishlayapti”.
2. Ulashish → “Bosh ekranga qo‘shish”. Ilova bosh ekrandan ochiladi.
3. Samolyot rejimida ochiladi.
4. Til/mavzu saqlanishi (ilovani to‘liq yopib ochgandan keyin).
5. Xavfsiz maydon (notch/pastki chiziq): pastki menyu tugmalari yopilib qolmasin.
6. Eslatma: Safari saytga 7 kun kirilmasa ma’lumotni o‘chirishi mumkin; bosh ekranga qo‘shilgan ilovada bu qoida qo‘llanmaydi. Shuning uchun 6-bosqichdan keyin zaxira majburiy tavsiya etiladi.

## C. Har bosqichdan keyin takrorlanadi
- Oflayn ishlash · yangilanishdan keyin ma’lumot saqlanishi · til/mavzu · 320 px kenglikda ko‘rinish · klaviatura bilan yurish.

## Avtomatik testlar (kompyuter muhitida bajarilgan)
Statik (30 ta): sintaksis, 3 tilda kalitlar mosligi, keshdagi fayllar, manifest, xavfsizlik andozalari, rang kontrasti.
Brauzer (33 ta): oflayn qayta yuklash, til/mavzu saqlanishi, migratsiya v1→v2, yangilanish oqimi, a11y, 320/390 px, reduced-motion, tezlik.
